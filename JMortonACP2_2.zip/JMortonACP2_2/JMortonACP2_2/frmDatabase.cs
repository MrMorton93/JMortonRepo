﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SQLite;
using System.IO;

namespace JMortonACP2_2
{
    public partial class frmDatabase : Form
    {
        SQLiteConnection sqlite_conn;
        string myInfo;

        public frmDatabase()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            SQLiteCommand cmd;
            cmd = sqlite_conn.CreateCommand();
            //drop it if it there
            cmd.CommandText = "DROP TABLE IF EXISTS graphicnovels";
            cmd.ExecuteNonQuery();

            //create table with 4 columns, primary key title main character, genre, year
            cmd.CommandText = @"CREATE TABLE graphicnovels(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT, author TEXT, genre TEXT,
            release_year INTEGER, publisher TEXT, adapted BIT)";
            cmd.ExecuteNonQuery();
            MessageBox.Show("Table Created");
        }

        static SQLiteConnection CreateConnection()
        {
            SQLiteConnection sqlite_conn;

            sqlite_conn = new SQLiteConnection("Data Source=graphicnovels.db");
            //open conn
            try
            {
                sqlite_conn.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            return sqlite_conn;
        }

        private void frmDatabase_Load(object sender, EventArgs e)
        {
            sqlite_conn = CreateConnection();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            SQLiteCommand cmd;
            cmd = sqlite_conn.CreateCommand();
            cmd.CommandText = "INSERT INTO graphicnovels (title, author, genre, release_year, publisher, adapted) VALUES ('Crisis on Infinite Earths', 'Marv Wolfman', 'Superhero', 1985, 'DC', 1)";
            cmd.ExecuteNonQuery();
            cmd.CommandText = "INSERT INTO graphicnovels (title, author, genre, release_year, publisher, adapted) VALUES ('Miles Morales: Straight out of Brooklyn', 'Saladin Ahmed', 'Superhero', 2019, 'Marvel', 0)";
            cmd.ExecuteNonQuery();
            cmd.CommandText = "INSERT INTO graphicnovels (title, author, genre, release_year, publisher, adapted) VALUES ('Hellboy: Seed of Destruction', 'Mike Mignola', 'Superhero', 1994, 'Dark Horse', 1)";
            cmd.ExecuteNonQuery();
            cmd.CommandText = "INSERT INTO graphicnovels (title, author, genre, release_year, publisher, adapted) VALUES ('V for Vendetta', 'Alan Moore', 'Superhero', 1982, 'DC', 1)";
            cmd.ExecuteNonQuery();
            cmd.CommandText = "INSERT INTO graphicnovels (title, author, genre, release_year, publisher, adapted) VALUES ('The League of Extraordinary Gentlemen', 'Alan Moore', 'Superhero/Alternate History', 1999, 'DC', 1)";
            cmd.ExecuteNonQuery();
            cmd.CommandText = "INSERT INTO graphicnovels (title, author, genre, release_year, publisher, adapted) VALUES ('Monstress', 'Marjorie Liu', 'Epic Fantasy', 2015, 'Image', 0)";
            cmd.ExecuteNonQuery();
            cmd.CommandText = "INSERT INTO graphicnovels (title, author, genre, release_year, publisher, adapted) VALUES ('Hellspawn', 'Brian Michael Bendis', 'Superhero/Horror', 2000, 'Image', 0)";
            cmd.ExecuteNonQuery();
            cmd.CommandText = "INSERT INTO graphicnovels (title, author, genre, release_year, publisher, adapted) VALUES ('The Walking Dead', 'Robert Kirkman', 'Horror', 2003, 'Image', 1)";
            cmd.ExecuteNonQuery();
            cmd.CommandText = "INSERT INTO graphicnovels (title, author, genre, release_year, publisher, adapted) VALUES ('The Mask', 'Doug Mahnke', 'Superhero', 1987, 'Dark Horse', 1)";
            cmd.ExecuteNonQuery();
            cmd.CommandText = "INSERT INTO graphicnovels (title, author, genre, release_year, publisher, adapted) VALUES ('Trekker', 'Ron Randall', 'Science Fiction', 1987, 'Dark Horse', 0)";
            cmd.ExecuteNonQuery();
            cmd.CommandText = "INSERT INTO graphicnovels (title, author, genre, release_year, publisher, adapted) VALUES ('Black Panther: A Nation Under Our Feet', 'Ta-Nehisi Coates', 'Superhero', 2016, 'Marvel', 0)";
            cmd.ExecuteNonQuery();
            cmd.CommandText = "INSERT INTO graphicnovels (title, author, genre, release_year, publisher, adapted) VALUES ('Ghost Rider: Road to Damnation', 'Garth Ennis', 'Superhero/Horror', 2006, 'Marvel', 0)";
            cmd.ExecuteNonQuery();
            cmd.CommandText = "INSERT INTO graphicnovels (title, author, genre, release_year, publisher, adapted) VALUES ('Locke & Key', 'Joe Hill', 'Horror', 2008, 'IDW', 1)";
            cmd.ExecuteNonQuery();
            cmd.CommandText = "INSERT INTO graphicnovels (title, author, genre, release_year, publisher, adapted) VALUES ('Teenage Mutant Ninja Turtles', 'Kevin Eastman', 'Superhero', 1984, 'IDW', 1)";
            cmd.ExecuteNonQuery();
            cmd.CommandText = "INSERT INTO graphicnovels (title, author, genre, release_year, publisher, adapted) VALUES ('Transformers: Lost Light', 'James Roberts', 'Science Fiction/Action-Adventure', 2012, 'IDW', 0)";
            cmd.ExecuteNonQuery();
            MessageBox.Show("Rows Created");
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            frmDisplay display = new frmDisplay();
            SQLiteDataReader dr;
            SQLiteCommand cmd;
            cmd = sqlite_conn.CreateCommand();
            cmd.CommandText = "SELECT * FROM graphicnovels ORDER BY publisher";
            dr = cmd.ExecuteReader();
            //I tried to format it as best as I could. I'm sorry
            display.lbxGraphicNovels.Items.Add("\t\t\tGraphic Novels\t\t\t");
            display.lbxGraphicNovels.Items.Add("ID\tTitle\t\t\t\t\tAuthor\t\t\tGenre\t\t\tYear\t\t\tPublisher\t\t\tAdapted");
            while (dr.Read())
            {
                myInfo = dr.GetInt32(0) + "\t" + dr.GetString(1) + "\t\t\t\t" + dr.GetString(2) + "\t\t\t\t" + dr.GetString(3) + "\t\t\t\t" + dr.GetInt32(4) + "\t\t\t\t" + dr.GetString(5)  + "\t" + dr.GetBoolean(6);
                display.lbxGraphicNovels.Items.Add(myInfo);
            }
            display.Show();
        }

        private void btnAbout_Click(object sender, EventArgs e)
        {
            frmAbout about = new frmAbout();
            about.ShowDialog();
        }

        private StringBuilder GenerateReport()
        {
            StringBuilder html = new StringBuilder();
            StringBuilder css = new StringBuilder();

            css.Append("<style>");
            css.Append("td {padding:5px;text-align:center;font-weight:bold;text-align:center;}");
            css.Append("h1{color: blue;}");
            css.Append("</style>");

            html.Append("<html>");
            html.Append($"<head>{css} <title>{"Graphic Novels"}</title></head>");
            html.Append("<body>");
            html.Append($"<h1><u>{"Graphic Novels"}</u></h1>");

            frmDisplay display = new frmDisplay();
            SQLiteDataReader dr;
            SQLiteCommand cmd;
            cmd = sqlite_conn.CreateCommand();
            cmd.CommandText = "SELECT * FROM graphicnovels ORDER BY publisher";
            dr = cmd.ExecuteReader();

            html.Append("<table>");
            html.Append("<tr><td colspan=5><hr/></td></tr>");
            html.Append("<tr>");
            html.Append("<th>ID</th>");
            html.Append("<th>Title</th>");
            html.Append("<th>Author</th>");
            html.Append("<th>Genre</th>");
            html.Append("<th>Year Published</th>");
            html.Append("<th>Publisher</th>");
            html.Append("<th>Adapted</th>");
            html.Append("</tr>");
            html.Append("<tr>");
            while (dr.Read())
            {
                myInfo = dr.GetInt32(0) + "\t" + dr.GetString(1) + "\t" + dr.GetString(2) + "\t" + dr.GetString(3) + "\t" + dr.GetInt32(4) + "\t" + dr.GetString(5) + "\t" + dr.GetBoolean(6);
                html.Append($"<td>{dr.GetInt32(0)}</td>");
                html.Append($"<td>{dr.GetString(1)}</td>");
                html.Append($"<td>{dr.GetString(2)}</td>");
                html.Append($"<td>{dr.GetString(3)}</td>");
                html.Append($"<td>{dr.GetInt32(4)}</td>");
                html.Append($"<td>{dr.GetString(5)}</td>");
                html.Append($"<td>{dr.GetBoolean(6)}</td>");
                html.Append("</tr>");
            }
            html.Append("<tr><td colspan=6><hr/></td></tr>");
            html.Append("</table>");
            html.Append("</body></html>");

            return html;
        }

        private void PrintReport(StringBuilder html)
        {
            //write to hard drive using the name report.html
            try
            {
                //using statement will automatically close a file after opening it
                using (StreamWriter wr = new StreamWriter("Report.html"))
                {
                    wr.WriteLine(html);
                }
                System.Diagnostics.Process.Start(@"Report.html");

            }
            catch (Exception ex)
            {
                MessageBox.Show("You don't have write permissions", "Error System Permissions",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            DateTime today = DateTime.Now;
            using (StreamWriter wr = new StreamWriter($"{today.ToString("yyyy--MM-DD-HHmmss")}Report.html"))
            {
                wr.WriteLine(html);
            }
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            PrintReport(GenerateReport());
        }
    }
}
